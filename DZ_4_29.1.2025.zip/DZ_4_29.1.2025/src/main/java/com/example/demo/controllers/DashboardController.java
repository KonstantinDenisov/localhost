package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Controller
@RequestMapping("/")
public class DashboardController {

    private final MeterRegistry meterRegistry;
    private long delayTime = 0;
    private int maxAllowedRequests = Integer.MAX_VALUE;  // Переименовано с maxRequests
    private int failureProbability = 0;  // Переименовано с errorChance

    private final AtomicInteger requestCount = new AtomicInteger(0);
    private final AtomicInteger successfulRequestCount = new AtomicInteger(0);

    public DashboardController(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        meterRegistry.gauge("dashboard.max_allowed_requests", this, controller -> controller.getMaxAllowedRequests());
        meterRegistry.gauge("dashboard.failure_probability", this, controller -> controller.getFailureProbability());
    }

    @GetMapping
    public String showDashboard(Model model) {
        model.addAttribute("delayTime", delayTime);
        model.addAttribute("maxAllowedRequests", maxAllowedRequests);
        model.addAttribute("failureProbability", failureProbability);
        model.addAttribute("successRate", calculateSuccessRate());
        return "dashboard";
    }

    @PostMapping("/settings")
    public String saveSettings(
            @RequestParam long delayTime,
            @RequestParam int maxAllowedRequests,
            @RequestParam int failureProbability) {
        this.delayTime = delayTime;
        this.maxAllowedRequests = maxAllowedRequests;
        this.failureProbability = failureProbability;
        return "redirect:/";
    }

    @PostMapping("/api/process")
    public String processRequest(
            @RequestParam int age, Model model) {
        requestCount.incrementAndGet();

        if (requestCount.get() > maxAllowedRequests) {
            updateModel(model);
            model.addAttribute("errorMessage", "Max request limit reached");
            return "dashboard";
        }

        if (new Random().nextInt(100) < failureProbability) {
            updateModel(model);
            model.addAttribute("errorMessage", "An error occurred during processing");
            return "dashboard";
        }

        successfulRequestCount.incrementAndGet();

        try {
            Thread.sleep(delayTime);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            model.addAttribute("errorMessage", "Request interrupted");
            return "dashboard";
        }

        // Генерация оставшихся лет жизни
        int remainingYears = getRemainingYears(age);

        updateModel(model);
        model.addAttribute("remainingYears", remainingYears);
        return "dashboard";
    }

    private int getRemainingYears(int age) {
        // Максимальный возраст 100 лет
        int maxAge = 100;
        int minAge = 60;
        int maxRemainingYears = maxAge - age; // оставшиеся года, если дожить до 100
    
        // Проверяем, чтобы оставшиеся годы были больше 0
        if (maxRemainingYears <= 0) {
            return 0;  // Если возраст больше или равен 100, то оставшиеся года = 0
        }
    
        // Генерация случайного числа оставшихся лет в пределах допустимого диапазона
        Random rand = new Random();
        return rand.nextInt(maxRemainingYears) + 1;  // От 1 года до оставшихся лет
    }

    private void updateModel(Model model) {
        model.addAttribute("delayTime", delayTime);
        model.addAttribute("maxAllowedRequests", maxAllowedRequests);
        model.addAttribute("failureProbability", failureProbability);
        model.addAttribute("successRate", calculateSuccessRate());
    }

    public int getMaxAllowedRequests() {
        return maxAllowedRequests;
    }

    public void setMaxAllowedRequests(int maxAllowedRequests) {
        this.maxAllowedRequests = maxAllowedRequests;
    }

    public int getFailureProbability() {
        return failureProbability;
    }

    private double calculateSuccessRate() {
        if (requestCount.get() == 0) {
            return 0;
        }
        return (successfulRequestCount.get() / (double) requestCount.get()) * 100;
    }
}